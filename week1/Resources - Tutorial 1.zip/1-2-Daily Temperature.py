# -*- coding: utf-8 -*-
"""
Created on Mon Aug  2 13:17:07 2021

CZ4124 Data Visualisation (Tutorial 1 Template)
@author: Put your name here
 
"""

import matplotlib.pyplot as plt
import pandas as pd

PlotWithPandas = True  # you can plot either with Pandas or Matplotlib
#---------------------------------------------------------------------
# Read in Daily Temperature datafile into dataframe Temp
#---------------------------------------------------------------------
Temp = pd.read_csv('C:/Datasets/Daily_Temperature.csv')  # change to your directory
print('\nTable read in\n',Temp,'\n')

#---------------------------------------------------------------------
# Use MELT to covert to long form and apply column names
#---------------------------------------------------------------------
# put in your code here


#---------------------------------------------------------------------
# Use PIVOT to convert to wide form with Names in each column
#---------------------------------------------------------------------
# put in your code here


#-------------------------------
# Use Pandas to plot line chart
#-------------------------------
if(PlotWithPandas):
    print('\nPlotting with Pandas')
    # put your Pandas plotting code here

    
#----------------------------------
# Use Matplotlib to plot line chart
#----------------------------------
else:  
    print('\nPlotting with Matplotlib')
    # Alternatively, you can do the plot using Matplotlib or 
    # any other Python plotting library

